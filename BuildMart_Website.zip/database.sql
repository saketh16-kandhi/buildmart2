CREATE DATABASE IF NOT EXISTS buildmart CHARACTER SET utf8mb4; USE buildmart;
CREATE TABLE products(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(140) NOT NULL,category VARCHAR(80) NOT NULL,description VARCHAR(255),price DECIMAL(10,2) NOT NULL,unit VARCHAR(30),image VARCHAR(255),stock INT DEFAULT 0,featured TINYINT DEFAULT 0,active TINYINT DEFAULT 1);
CREATE TABLE orders(id INT AUTO_INCREMENT PRIMARY KEY,customer_name VARCHAR(120),phone VARCHAR(40),address TEXT,preferred_date DATE,total DECIMAL(12,2),status ENUM('Pending','Processing','Dispatched','Delivered','Cancelled') DEFAULT 'Pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE order_items(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT,product_id INT,quantity INT,unit_price DECIMAL(10,2),FOREIGN KEY(order_id) REFERENCES orders(id),FOREIGN KEY(product_id) REFERENCES products(id));
CREATE TABLE requests(id INT AUTO_INCREMENT PRIMARY KEY,request_type ENUM('quote','vehicle','equipment'),item_name VARCHAR(140),customer_name VARCHAR(120),phone VARCHAR(40),address TEXT,preferred_date DATE,quantity VARCHAR(80),notes TEXT,status ENUM('Pending','Processing','Dispatched','Delivered','Cancelled') DEFAULT 'Pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT INTO products(name,category,description,price,unit,image,stock,featured) VALUES
('OPC 53 Grade Cement','Cement','High-strength cement for foundations and structural work.',390,'bag','',120,1),
('River Sand','Sand & Aggregates','Washed construction sand for concrete and masonry.',1850,'ton','',35,1),
('Red Clay Bricks','Bricks & Blocks','Durable uniform bricks for walls and partitions.',9,'piece','',5000,1),
('TMT Steel Rods','Steel & Iron','Reinforcement bars for structural strength.',68,'kg','',800,1),
('20mm Aggregate','Sand & Aggregates','Crushed stone aggregate for concrete.',1450,'ton','',42,0),
('PVC Plumbing Kit','Plumbing & Electrical','Essential pipes and fittings.',1250,'set','',24,0);
