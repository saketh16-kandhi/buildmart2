<?php
// XAMPP default credentials; change if your local MySQL setup differs.
$host='localhost'; $database='buildmart'; $username='root'; $password='';
try {
  $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8mb4",$username,$password,[
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
  ]);
} catch(PDOException $e) { $pdo=null; }
