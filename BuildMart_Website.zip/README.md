# BuildMart — Construction Supply, Vehicle & Equipment Ordering Website

This project follows the uploaded BuildMart mini-project proposal: material catalog, vehicle delivery requests, equipment rental enquiries, cart/checkout, order tracking, and responsive layout.

## Run the front-end demo
1. Extract the ZIP.
2. Open `index.html` in a browser, or use VS Code Live Server.
3. Search/filter products, add items to cart, submit vehicle/equipment requests, and track the generated `BM-xxxxxx` reference in the same browser.
4. Demo cart and requests are saved in browser `localStorage`.

## XAMPP / PHP + MySQL setup (database foundation)
1. Copy the `BuildMart_Website` folder into XAMPP's `htdocs`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin at `http://localhost/phpmyadmin`.
4. Import `database.sql`.
5. Edit database credentials in `includes/db.php` if needed.

The delivered website runs as a front-end academic prototype. The included SQL schema is the database foundation for products, orders, order items, and requests. The browser-only demo does not send real orders to suppliers or process payments. Complete server-side integration and an authenticated admin dashboard are future implementation work.

## Technology stack
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend plan: PHP
- Database: MySQL / MariaDB
- Local environment: XAMPP
